package com.billpocket.integrationtest

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.billpocket.integrationtest.databinding.ActivityMainBinding
import com.billpocket.libs.integration.BPIntentBuilder
import com.billpocket.libs.integration.BPPaymentResponse
import java.math.BigDecimal


class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var resultLauncher: ActivityResultLauncher<Intent>
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnRequest.setOnClickListener(this)
        binding.btnResponse.setOnClickListener(this)
        binding.requestLayout.btnSend.setOnClickListener(this)
        binding.requestLayout.btnWebHook.setOnClickListener(this)
        setupResultLauncher()
        val intent = intent
        val uri = intent.data
        if (uri != null) {
            binding.btnResponse.performClick()
            binding.responseLayout.responseText.text = uri.toString()
        }
        binding.requestLayout.txtIdent.setText(Util.getDeviceId(this))
    }

    private fun setupResultLauncher() {
         resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                binding.btnResponse.performClick()
                val response = BPPaymentResponse.parseResult(data)
                binding.responseLayout.responseText.text = response.toString()            }
        }
    }

    private fun getValueOf(editText: EditText): String {
        return editText.text.toString().trim { it <= ' ' }
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.main, menu);
        return false
    }

    override fun onClick(view: View) {
        val id = view.id
        if (id == R.id.btnRequest) {
            binding.requestLayout.root.visibility = View.VISIBLE
            binding.responseLayout.root.visibility = View.GONE
        } else if (id == R.id.btnResponse) {
            binding.requestLayout.root.visibility = View.GONE
            binding.responseLayout.root.visibility = View.VISIBLE
        } else {
            val builder = BPIntentBuilder()
                .setAction(BPIntentBuilder.INTEGRATION_ACTION_BILLPOCKET)
                .setTransactionType(BPIntentBuilder.TRANSACTION_TYPE_SALE)
                .setIdentifier(getValueOf(binding.requestLayout.txtIdent))
                .setDescription(getValueOf(binding.requestLayout.txtDescription))
                .setMailRecipient(getValueOf(binding.requestLayout.txtEmail))
                .setSmsRecipient(getValueOf(binding.requestLayout.txtPhone))
                .setUserToken(getValueOf(binding.requestLayout.txtToken)) //this token is located in https://test.dashboard.billpocket.com/panel/integraciones
                .setMandatoryPhoto(false)
                .setHidePrinterOption(true)
                .setSkipSendMailOption(true)
            val amount = getValueOf(binding.requestLayout.txtAmount)
            val tip = getValueOf(binding.requestLayout.txtTip)
            if (!amount.isEmpty()) {
                builder.setAmount(BigDecimal(amount))
            }
            if (!tip.isEmpty()) {
                builder.setTip(BigDecimal(tip))
            }
            val signatureTries = getValueOf(binding.requestLayout.txtSkipSignatureTries)
            if (signatureTries.matches(Regex("[0-9]+"))) {
                builder.setSkipSignatureAfterTries(signatureTries.toInt())
            }
            val msiParameter = getValueOf(binding.requestLayout.txtMSI)
            if (msiParameter.matches(Regex("[0-9]+"))) {
                builder.setDeferredPayments(msiParameter.toInt())
            }
            val deviceToken = getValueOf(binding.requestLayout.txtDeviceToken)//this value is located in https://dashboard.billpocket.com/panel/dispositivos
            if (!deviceToken.isEmpty()) {
                builder.setDeviceToken(deviceToken)
            }
            val intent = builder.build()
            Log.d("Extras", intent.extras.toString())
            if (id == R.id.btnSend) {
                if (intent.resolveActivity(packageManager) != null) {
                    resultLauncher.launch(intent)
                }
            } else if (id == R.id.btnWebHook) {
                showWebHookDialog(Util.intentToURL(intent))
            }
        }
    }

    private fun showWebHookDialog(url: String) {
        val dBuilder: AlertDialog.Builder = AlertDialog.Builder(this)
            .setTitle("Request")
            .setMessage(url)
            .setPositiveButton("Sure", DialogInterface.OnClickListener { dialog, _ ->
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                }
                dialog.dismiss()
            }).setNegativeButton("Cancel",
                DialogInterface.OnClickListener { dialog, _ -> dialog.dismiss() })

        val alertDialog: AlertDialog = dBuilder.create()
        alertDialog.show()
    }
}