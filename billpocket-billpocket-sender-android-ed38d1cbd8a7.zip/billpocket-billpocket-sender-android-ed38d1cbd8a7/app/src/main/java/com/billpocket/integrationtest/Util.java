package com.billpocket.integrationtest;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;

import java.security.SecureRandom;
import java.util.Locale;

public class Util {

    private static final String SHARED_PREFERENCES = "my_shared_prefs";
    private static final String DEVICE_ID = "device_id";
    public static final int DEVICE_ID_BYTE_LENGTH = 20;
    private static final char[] HEX = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };


    public static String intentToURL(@NonNull Intent intent){

        Uri.Builder builder = new Uri.Builder()
                .scheme("billpocket")
                .authority("")
                .appendQueryParameter("urlScheme", Uri.encode("bpsender://"));

        Bundle bundle = intent.getExtras();

        if (bundle != null) {

            for (String key : bundle.keySet()) {

                String val = String.valueOf(bundle.get(key));

                if (!val.isEmpty()){
                    builder.appendQueryParameter(key, Uri.encode(val));
                }
            }
        }

        return builder.build().toString();
    }

    public static String getDeviceId(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SHARED_PREFERENCES, Context.MODE_PRIVATE);
        if (sp.contains(DEVICE_ID)) {
            return sp.getString(DEVICE_ID, null);
        }
        String deviceId = getSuperDuperNuevoID();
        sp.edit().putString(DEVICE_ID, deviceId).apply();
        return deviceId;
    }

    @NonNull
    public static String getSuperDuperNuevoID() {

        final String newDeviceID;

        byte[] deviceIDBytes = new byte[DEVICE_ID_BYTE_LENGTH];

        new SecureRandom().nextBytes(deviceIDBytes);

        newDeviceID = byteArrayToHexString(deviceIDBytes).toLowerCase(Locale.US);

        return newDeviceID;

    }

    public static String byteArrayToHexString(byte[] src) {
        return byteArrayToHexString(src, 0, src.length);
    }

    public static String byteArrayToHexString(byte[] scr, int off, int len) {
        final char[] buf = new char[len * 2];

        for (int i = 0, j = 0; i < len; i++) {
            buf[j++] = HEX[((scr[off + i] >> 4) & 0xf)];
            buf[j++] = HEX[((scr[off + i]) & 0xf)];
            //buf[j++] = ' ';
        }

        return new String(buf);
    }
}
