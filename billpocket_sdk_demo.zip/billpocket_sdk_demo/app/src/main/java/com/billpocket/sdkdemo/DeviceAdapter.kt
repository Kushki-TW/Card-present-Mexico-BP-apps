package com.billpocket.sdkdemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.billpocket.sdkdemo.databinding.ItemDeviceselectorBinding
import com.billpocket.sdkdemo.utils.ItemClickListener

class DeviceAdapter(private val devices: List<String>):
    RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>(),
    View.OnClickListener {

    var itemClickListener: ItemClickListener<String>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        DeviceViewHolder(
            ItemDeviceselectorBinding.inflate(LayoutInflater.from(parent.context), parent, false),
            this)

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        holder.bind(devices[position])
    }

    override fun getItemCount() = devices.size

    override fun onClick(v: View?) { itemClickListener?.invoke(v?.tag as String) }

    //viewholder del selector
    inner class DeviceViewHolder(
        private val binding: ItemDeviceselectorBinding,
        clickListener: View.OnClickListener): RecyclerView.ViewHolder(binding.root){

        init { binding.root.setOnClickListener(clickListener) }

        fun bind(element: String){
            binding.element = element
            binding.executePendingBindings()
        }
    }

}