package com.billpocket.sdkdemo

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.billpocket.bil_lib.controllers.BillpocketPrinter
import com.billpocket.bil_lib.controllers.HistoryTransactions
import com.billpocket.bil_lib.core.interfaces.EventListenerRefundPayment
import com.billpocket.bil_lib.core.interfaces.ReturnPaymentResult
import com.billpocket.bil_lib.models.entities.RefundPaymentData
import com.billpocket.bil_lib.models.entities.RefundTransactionResponse
import com.billpocket.bil_lib.models.entities.Transaction
import com.billpocket.sdkdemo.databinding.ActivityTransactiondetailBinding
import com.billpocket.sdkdemo.utils.showToast
import com.google.gson.Gson

class TransactionDetailActivity: AppCompatActivity(), EventListenerRefundPayment,
    BillpocketPrinter.EventListenerPrinter {

    private lateinit var binding: ActivityTransactiondetailBinding

    private val transaction by lazy {
        Gson().fromJson(intent.getStringExtra("DETAILS"), Transaction::class.java)
    }

    private var loader: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_transactiondetail)
        binding.transaction = transaction

        //reembolso
        binding.refund.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.app_name)
                .setMessage(R.string.caption_refundtransaction)
                .setPositiveButton(R.string.action_accept) { _, _ ->
                    //se crea el loader
                    loader = AlertDialog.Builder(this).setView(R.layout.dialog_loader).create()
                    loader?.show()
                    //se bloquea la UI
                    binding.refund.isEnabled = false
                    //se ejecuta la transacción
                    HistoryTransactions.refundPayment(
                        RefundPaymentData(
                            transaction.latitude.toString(),
                            transaction.longitude.toString(),
                            transaction.amount.toString(),
                            transaction.id.toString()),
                        this@TransactionDetailActivity)
                }
                .setNegativeButton(R.string.action_cancel, null)
                .show()
        }

        //impresión de ticket
        binding.print.setOnClickListener {
            //se crea el loader
            loader = AlertDialog.Builder(this).setView(R.layout.dialog_loader).create()
            loader?.show()
            //se bloquea la UI
            binding.print.isEnabled = false
            //se ejecuta la transacción
            BillpocketPrinter.printTicket("163920016", this, this)
        }
    }

    override fun resultRefundPayment(result: ReturnPaymentResult<RefundTransactionResponse>) {
        loader?.dismiss()
        when(result){
            is ReturnPaymentResult.Success -> {
                setResult(RESULT_OK)
                showToast(R.string.caption_transactionrefunded, lenghtLong = true)
                finish()
            }
            is ReturnPaymentResult.Error -> {
                binding.refund.isEnabled = true
                showToast(result.exception.message ?: "No se puede reembolsar la transacción",
                    lenghtLong = true)
            }
        }
    }

    override fun onResult(result: BillpocketPrinter.PrintResult) {
        loader?.dismiss()
        when(result){
            is BillpocketPrinter.PrintResult.Success -> {
                setResult(RESULT_OK)
                showToast(R.string.caption_ticketprinted, lenghtLong = true)
            }
            is BillpocketPrinter.PrintResult.Error -> {
                binding.refund.isEnabled = true
                showToast(result.message, lenghtLong = true)
            }
        }
    }

}