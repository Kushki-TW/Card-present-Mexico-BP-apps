package com.billpocket.sdkdemo.utils

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat

//nombre, tipo, dirección
typealias BPDevice = Triple<String, Int, String>
typealias ItemClickListener<T> = (data: T) -> Unit
typealias DataCallback<T> = (data: T) -> Unit

val df = DecimalFormat("#.##").apply { roundingMode = RoundingMode.DOWN }

sealed class SDKStatus {
    object Loading: SDKStatus()
    data class Success(val message: String): SDKStatus()
    data class Error(val message: String): SDKStatus()
}

class MSIOption(val installments: Int,
                val fee: BigDecimal,
                val minAmount: BigDecimal){

    val adjustedFee: String get() = df.format(fee.toDouble())

}