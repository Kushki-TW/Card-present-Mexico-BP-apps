package com.billpocket.sdkdemo

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.billpocket.bil_lib.models.entities.Transaction
import com.billpocket.sdkdemo.databinding.ItemTransactionhistoryBinding
import com.billpocket.sdkdemo.utils.ItemClickListener

class TransactionAdapter:
    RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder>(),
    View.OnClickListener {

    private val transactions: MutableList<Transaction> = mutableListOf()

    var itemClickListener: ItemClickListener<Transaction>? = null

    @SuppressLint("NotifyDataSetChanged")
    fun setItems(items: List<Transaction>){
        transactions.clear()
        transactions.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        TransactionViewHolder(
            ItemTransactionhistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false),
            this)

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        holder.bind(transactions[position])
    }

    override fun getItemCount() = transactions.size

    override fun onClick(v: View?) { itemClickListener?.invoke(v?.tag as Transaction) }

    //viewholder del selector
    inner class TransactionViewHolder(
        private val binding: ItemTransactionhistoryBinding,
        clickListener: View.OnClickListener): RecyclerView.ViewHolder(binding.root){

        init { binding.root.setOnClickListener(clickListener) }

        fun bind(element: Transaction){
            binding.element = element
            binding.executePendingBindings()
        }
    }

}