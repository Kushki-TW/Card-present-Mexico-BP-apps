package com.billpocket.sdkdemo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.billpocket.sdkdemo.databinding.DialogDeviceselectorBinding
import com.billpocket.sdkdemo.utils.BPDevice
import com.billpocket.sdkdemo.utils.DataCallback
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class SelectDeviceFragment: BottomSheetDialogFragment() {

    companion object {
        private const val ARG_DEVICES = "devices"

        fun newInstance(devices: List<BPDevice>) =
            SelectDeviceFragment().apply {
                arguments = Bundle().apply {
                    putStringArrayList(ARG_DEVICES, ArrayList(devices.map { it.first }))
                }
            }

    }

    private val devices by lazy {
        requireArguments().getStringArrayList(ARG_DEVICES)?.toList() ?: emptyList() }

    private val adapter by lazy {
        DeviceAdapter(devices).apply {
            itemClickListener = {
                callback?.invoke(it)
                dismiss()
            }
        }
    }
    var callback: DataCallback<String>? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<DialogDeviceselectorBinding>(
            inflater, R.layout.dialog_deviceselector, container, false)
        binding.list.adapter = adapter
        return binding.root
    }

}