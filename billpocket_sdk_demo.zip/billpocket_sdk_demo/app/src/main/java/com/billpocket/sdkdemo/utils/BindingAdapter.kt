package com.billpocket.sdkdemo.utils

import android.widget.TextView
import androidx.databinding.BindingAdapter
import com.billpocket.sdkdemo.R
import java.math.BigDecimal

object BindingAdapter {

    @JvmStatic
    @BindingAdapter("bigDecimalAsCurrency")
    fun formatBigDecimalAsCurrency(textView: TextView, bigDecimal: BigDecimal?){
        if(bigDecimal != null)
            textView.text = bigDecimal.asCurrency()
    }

    @JvmStatic
    @BindingAdapter("longAsDate")
    fun formatLongAsDate(textView: TextView, long: Long?){
        if(long != null)
            textView.text = long.asSimpleDate()
    }

    @JvmStatic
    @BindingAdapter("longAsFullDate")
    fun formatLongAsFullDate(textView: TextView, long: Long?){
        if(long != null)
            textView.text = long.asFullDate()
    }

    @JvmStatic
    @BindingAdapter("showStatus")
    fun showSDKStatus(textView: TextView, status: SDKStatus?){
        if(status != null)
            when(status){
                is SDKStatus.Loading -> textView.setText(R.string.label_initsdk)
                is SDKStatus.Success -> textView.setSuccessMessage(status.message)
                is SDKStatus.Error -> textView.setErrorMessage(status.message)
            }
    }

}