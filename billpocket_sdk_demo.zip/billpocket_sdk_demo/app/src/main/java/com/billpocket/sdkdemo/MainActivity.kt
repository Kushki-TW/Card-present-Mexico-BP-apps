package com.billpocket.sdkdemo

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.billpocket.bil_lib.controllers.BillpocketSDK
import com.billpocket.bil_lib.controllers.BluetoothReaderConnection
import com.billpocket.bil_lib.controllers.BluetoothReaderList
import com.billpocket.bil_lib.controllers.BluetoothReaderTransaction
import com.billpocket.bil_lib.core.BluetoothDevicesResult
import com.billpocket.bil_lib.core.InitSDKResult
import com.billpocket.bil_lib.core.ReaderConnectionResult
import com.billpocket.bil_lib.core.ReaderDisconnectionResult
import com.billpocket.bil_lib.core.interfaces.*
import com.billpocket.bil_lib.models.entities.DataReader
import com.billpocket.bil_lib.models.entities.DataSuccessfulTransaction
import com.billpocket.bil_lib.models.transaction.Q6Descriptor
import com.billpocket.minerva.core.PlainPINCaptureActivity
import com.billpocket.sdkdemo.databinding.ActivityMainBinding
import com.billpocket.sdkdemo.utils.*

class MainActivity() : AppCompatActivity(), EventListenerConnection, EventListenerTransaction,
    Parcelable {

    private lateinit var binding: ActivityMainBinding
    private var btAdapter: BluetoothAdapter? = null

    private  lateinit var  spiner :Spinner

    private val environment = InitBillpocketSDK.SdkMode.TEST
    private var currentDevice: String? = null

    //resultados de peticiones
    private val requestBluetoothPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            var allAccepted = true
            permissions.entries.forEach { allAccepted = allAccepted && it.value }
            if(allAccepted)
                showToast(R.string.caption_permission_bluetooth_accepted)
            else
                showToast(R.string.caption_permission_bluetooth_rejected)
        }

    private val requestBluetoothStart =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            if(it.resultCode == RESULT_OK)
                showToast(R.string.caption_bluetoothactivated)
            else
                showToast(R.string.caption_bluetoothdisabled)
        }

    private val requestPIN =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ result ->
            if(result.resultCode == RESULT_OK)
                BluetoothReaderTransaction.continueTransactionWithPIn(result.data!!,this)
        }

    private val requestSignature =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){ result ->
            if(result.resultCode == RESULT_OK)
                BluetoothReaderTransaction.continueTransactionWithSignature(result.data!!)
        }

    constructor(parcel: Parcel) : this() {
        currentDevice = parcel.readString()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //verificación de permisos Bluetooth
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) ==
                PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED)
                showToast(R.string.caption_permission_bluetooth_accepted)
            else {
                requestBluetoothPermissions.launch(arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT))
            }
        }



        //inicialización de objetos
        btAdapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

       BillpocketSDK.isReaderSunmi(object: EventListenerInitSDK {
           override fun messageTrackeo(message: String) {
               Log.e("transaction", message)
           }

           override fun resultInitSdk(resultInitSdk: InitSDKResult<String>) {
                //se ignora
            }

            //si el SDK se inicializa en un dispositivo SUNMI, se obtendrá aquí
            override fun resultIsReaderSunmi(isSunmi: Boolean) {
                binding.inSunmi = isSunmi
                //el lector se considera "conectado" al estar en una Sunmi
                if(isSunmi)
                    binding.paired = true
            }
        })
        //incializar SDK
        binding.sdkStatus = SDKStatus.Loading

        BillpocketSDK.sdkStatus()

        BillpocketSDK.initSDK(this,
            environment, //cambiar entre modos aquí
            BuildConfig.SDK_TOKEN, //usar tu token aquí
            object: EventListenerInitSDK {
                override fun messageTrackeo(message: String) {
                    Log.d("trackeo", message)
                }

                //si hay un problema con inicializar el SDK se mosrtrará aquí
                override fun resultInitSdk(resultInitSdk: InitSDKResult<String>) {
                    when(resultInitSdk){
                        is InitSDKResult.Success -> {
                            Log.d("InitTest", "${resultInitSdk.data}")
                            binding.sdkStatus = SDKStatus.Success(resultInitSdk.data)
                            //se muestra el ambiente en el cual está inicializado
                            binding.sdkEnvironment.visibility = View.VISIBLE
                            binding.sdkEnvironment.text = getString(
                                    if(environment == InitBillpocketSDK.SdkMode.PRODUCTION)
                                        R.string.label_sdkmode_production
                                    else
                                        R.string.label_sdkmode_test)
                            //se habilita el botón para iniciar la búsqueda
                            binding.selectReader.isEnabled = true
                        }
                        is InitSDKResult.Error ->{
                            Log.d("InitTest", "${resultInitSdk.exception.message}")
                            binding.sdkStatus = SDKStatus.Error(
                                resultInitSdk.exception.message ?:
                                getString(R.string.caption_error_sdk))
                        }
                    }
                }

              override fun resultIsReaderSunmi(isSunmi: Boolean) {
                    //se ignora
                }
            })

        //verificar conexión bluetooth
        binding.checkBluetooth.setOnClickListener {
            if(checkBluetooth())
                showToast(R.string.caption_bluetoothavailable)
            else {
                if (btAdapter?.isEnabled == false)
                    requestBluetoothStart.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                else
                    showToast(R.string.caption_bluetoothnotavailable)
            }
        }

        //obtener el historial de transacciones
        binding.transactionHistory.setOnClickListener {
            startActivity(Intent(this, TransactionsHistoryActivity::class.java))
        }

        //obtener lectores disponibles
        binding.selectReader.setOnClickListener {
            BluetoothReaderList.getListBluetoothReaders(this, this) }

        //desconectar lector pareado
        binding.disconnectReader.setOnClickListener {
            binding.disconnectReader.isEnabled = false
            BluetoothReaderConnection.disconnectReader(this, object: EventListenerDisconnection {
                override fun resultReaderDisconnection(resultDisconnection: ReaderDisconnectionResult<String>) {
                    when(resultDisconnection){
                        //el lector fue desconectado exitosamente
                        is ReaderDisconnectionResult.Success -> {
                            binding.disconnectReader.isEnabled = true
                            //se limpia la interfaz
                            binding.paired = false
                            binding.currentDevice.text = ""
                            binding.amount.setText("")
                            binding.tip.setText("")
                            binding.latitude.setText("")
                            binding.longitude.setText("")
                            binding.identifier.setText("")
                        }
                        //el lector no pudo ser desconectado
                        is ReaderDisconnectionResult.Error -> {
                            binding.disconnectReader.isEnabled = true
                            showToast(
                                resultDisconnection.exception.message ?:
                                getString(R.string.caption_error_readerdisconnection))
                        }
                    }
                }
            })
        }

        //iniciar transacción
        binding.startTransaction.setOnClickListener {
            binding.amount.showError(
                if(binding.amount.text.isEmpty()) getString(R.string.caption_error_amount) else null)
            binding.tip.showError(
                if(binding.tip.text.isEmpty()) getString(R.string.caption_error_amount) else null)
            binding.latitude.showError(
                if(binding.latitude.text.isEmpty()) getString(R.string.caption_error_amount) else null)
            binding.longitude.showError(
                if(binding.longitude.text.isEmpty()) getString(R.string.caption_error_amount) else null)

            //si los valores son válidos se puede proceder con la transacción
            if(binding.amount.text.isNotEmpty() && binding.tip.text.isNotEmpty() &&
                binding.latitude.text.isNotEmpty() && binding.longitude.text.isNotEmpty()){
                BluetoothReaderTransaction.doTransaction(
                    this,
                    binding.amount.text.toString().toBigDecimal(),
                    "Transacción de prueba", //puedes colocar el nombre que desees
                    //el provider puede ser el nombre que quieras
                    Location("SDK_EXAMPLE").apply {
                        latitude = binding.latitude.text.toString().toDouble()
                        longitude = binding.longitude.text.toString().toDouble()
                    },
                    binding.tip.text.toString().toBigDecimal(),
                    this)
            }
        }



        spiner =  binding.spiner
        initSpinner()
    }

    override fun onLogMessage(log: String) {
        Log.e("TRACKeo--", log)
    }

   override fun onQposDisconnected(resultDisconnected: String) {
        showToast(resultDisconnected, true)
    }

    /*     Eventos de lector, provenientes del EventListenerConection     */
    //se obtienen los dispositivos pareados
    override fun resultListReaders(readersList: BluetoothDevicesResult<List<BluetoothDevice>>) {
        when(readersList){
            is BluetoothDevicesResult.Success ->
                readDevices(readersList.data)?.let { devices ->
                    if(devices.isEmpty())
                        showToast(R.string.caption_bluetoothnodevices)
                    else
                    //si existen dispositivos se inicia el selector
                        SelectDeviceFragment.newInstance(devices).apply {
                            callback = { selected ->
                                devices.find { it.first == selected }?.let {
                                    currentDevice = it.first
                                    binding.currentDevice.setWaitingMessage(
                                        getString(R.string.caption_bluetoothactivereader, it.first))
                                    //se pasan los datos de conexión del dispositivo y se escucha el resultado
                                    BluetoothReaderConnection.connectReader(
                                        this@MainActivity, it.second, it.third, it.first,
                                        this@MainActivity)
                                }
                            }
                        }.show(supportFragmentManager, "select_device")
                } ?: showToast(R.string.caption_error_cannotreaddevices)
            is BluetoothDevicesResult.Error ->
                showToast(
                    readersList.exception.message ?: getString(R.string.caption_error_generic))
        }
    }

    //se parea con el dispositivo correspondiente
    override fun resultReaderConnect(resultConnection: ReaderConnectionResult<DataReader>) {
        when(resultConnection){
            is ReaderConnectionResult.Success -> {
                binding.paired = true
                binding.currentDevice.setSuccessMessage(
                    getString(R.string.caption_readerbaterrylevel,
                        currentDevice,
                        resultConnection.data.batteryLevel))
            }
            is ReaderConnectionResult.Error -> {
                binding.paired = false
                binding.currentDevice.setErrorMessage(
                    getString(R.string.caption_error_readerconnection,
                        currentDevice,
                        resultConnection.exception.message ?:
                        getString(R.string.caption_error_cannotconnectreader)))
            }
        }
    }


    /*     Eventos de transacción, provenientes del EventListenerTransaction     */
    //primer evento, se lanza al establecer conexión con el lector
    override fun onBeforeTransaction(message: String) {
        runOnUiThread {
            //se desactivan los botones para evitar comportamientos inesperados
            binding.startTransaction.isEnabled = false
            binding.disconnectReader.isEnabled = false
            //se actualiza UI
            binding.transactionState.setWaitingMessage(R.string.caption_status_beforetransaction)
            binding.stateDescription.setWaitingMessage(message)
            binding.msiSelected.visibility = View.GONE
        }
    }

    //se lanza al terminar de establecer conexión con el lector
    override fun resultStartTransaction(resultTransaction: ReaderTransactionResult<String>) {
        runOnUiThread {
            when(resultTransaction){
                is ReaderTransactionResult.Success -> {
                    binding.transactionState.setWaitingMessage(R.string.caption_status_starttransaction)
                    binding.stateDescription.setWaitingMessage(resultTransaction.data)
                }
                is ReaderTransactionResult.Error -> {
                    //se vuelven a habilitar los botones
                    binding.startTransaction.isEnabled = true
                    binding.disconnectReader.isEnabled = true
                    //se actualiza la UI
                    binding.transactionState.setErrorMessage(R.string.caption_error_starttransaction)
                    binding.stateDescription.setErrorMessage("${resultTransaction.exception.message}")
                }
            }
        }
    }

    fun initSpinner(){
        selectAplication(listOf("sin elementos"))
        binding.multiaplication.visibility = View.GONE
    }



    override fun selectAplication(list: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, list)
        spiner.adapter = adapter
        var posItemSelected = 0;

        spiner.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

                Toast.makeText(applicationContext, "Seleccionaste ${list.get(position)}", Toast.LENGTH_LONG).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                Toast.makeText(applicationContext, "Selecciona una opción", Toast.LENGTH_LONG).show()
            }
        }

        binding.multiaplication.visibility = View.VISIBLE

        binding.continueMultiaplication.setOnClickListener {
            binding.multiaplication.visibility = View.GONE
            BluetoothReaderTransaction.continueWithAppIndex(posItemSelected)
        }

    }



    //se espera a que la tarjeta sea introducida
    override fun onReaderWaitingForCard(message: String) {
        Log.d("ReaderWait" ,"se llama al metodo onReaderWait")

            Toast.makeText(
                this,
                "esperando tarjeta",
                Toast.LENGTH_LONG
            ).show()
            binding.transactionState.setWaitingMessage(R.string.caption_status_waitingforcard)
            binding.stateDescription.setWaitingMessage(message)
    }

    //la tarjeta está en el dispositivo
    override fun onCardRead(message: String) {
        Log.d("ReaderWait" ,"se llama al metodo onCardRead")
        runOnUiThread {
            Toast.makeText(
                this,
                "Leyendo tarjeta",
                Toast.LENGTH_LONG
            ).show()
            binding.transactionState.setWaitingMessage(R.string.caption_status_cardinreader)
            binding.stateDescription.setWaitingMessage(message)
        }
    }

    //se requiere pedir el PIN en la interfaz
    override fun onGetPin(intent: Intent, requestCodeMinerva: Int) {
        //se debe llamar a esta clase externa para capturar el PIN
        //nota: usar 'requestCodeMinerva' si se requiere usar un startActivityForResult
        intent.setClass(this, PlainPINCaptureActivity::class.java)
        requestPIN.launch(intent)
    }

    override fun onLogEvenListener(log: String) {
        Log.e("Tracketo----->", log)
    }
    override fun onMagneticCardFound(readerType: Int) {
         BluetoothReaderTransaction.onContinueTransactionWithMagneticCard()
     }

    //se requiere pedir la firma en la interfaz
    override fun getSignature(intent: Intent) {
        requestSignature.launch(intent)
    }

    //se requiere elegir los MSI en la interfaz
    @SuppressLint("SetTextI18n")
    override fun onMsiDefined(msiClient: MutableList<Q6Descriptor>) {
        SelectMSIFragment.newInstance(msiClient).apply {
            callback = {
                runOnUiThread {
                    binding.msiSelected.visibility = View.VISIBLE
                    binding.msiSelected.text = getString(R.string.caption_status_msi, it.installments)
                    BluetoothReaderTransaction.continueTransactionWithMSI(it)
                }
            }
        }.show(supportFragmentManager, "msi_selector")
    }

    //la transacción fue finalizada
    override fun onTransactionFinished(message: String) {
        runOnUiThread {
            //se vuelven a habilitar los botones
            binding.startTransaction.isEnabled = true
            binding.disconnectReader.isEnabled = true
            //se actualiuza UI
            binding.transactionState.setErrorMessage(R.string.caption_error_transactionfinished)
            binding.stateDescription.setErrorMessage(message)
        }
    }

    //la transacción fue exitosa
    override fun onTransactionSuccessful(msj: String, transactionData: DataSuccessfulTransaction) {
        runOnUiThread {
            //se vuelven a habilitar los botones
            Log.d("dataTRX","dataTransaction: $transactionData" )
            binding.startTransaction.isEnabled = true
            binding.disconnectReader.isEnabled = true
            //se actualiza UI
            binding.transactionState.setSuccessMessage(R.string.caption_status_sucessfultransaction)
            binding.stateDescription.setSuccessMessage(msj)
        }
    }

    //en caso de que la transacción sea terminada se cae en este caso
    //p.e. tiempo de espera agotado en el lector
    override fun onTransactionAborted(message: String) {
        runOnUiThread {
            //se vuelven a habilitar los botones
            binding.startTransaction.isEnabled = true
            binding.disconnectReader.isEnabled = true
            //se actualiza la UI
            binding.transactionState.setErrorMessage(R.string.caption_error_transactionaborted)
            binding.stateDescription.setErrorMessage(message)
        }
    }


    /*     Funciones de utilidad - no necesarias para usar el SDK     */
    private fun checkBluetooth() = btAdapter?.takeIf { it.isEnabled } != null

    @SuppressLint("MissingPermission")
    private fun readDevices(results: List<BluetoothDevice>) =
        //se requieren permisos a partir de Android 12
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            == PackageManager.PERMISSION_GRANTED)
            results.map { BPDevice(it.name, it.type, it.address) }
        else
            null

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(currentDevice)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MainActivity> {
        override fun createFromParcel(parcel: Parcel): MainActivity {
            return MainActivity(parcel)
        }

        override fun newArray(size: Int): Array<MainActivity?> {
            return arrayOfNulls(size)
        }
    }
}