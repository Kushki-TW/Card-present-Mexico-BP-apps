package com.billpocket.sdkdemo.utils

import android.app.Activity
import android.util.TypedValue
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import com.billpocket.sdkdemo.R
import com.google.android.material.textfield.TextInputLayout
import java.math.BigDecimal
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

object NumberExtensions {
    val currencyFormat = DecimalFormat("$#,###,##0.00")
}

object DateExtensions {
    val simpleFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val fullFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
}

/*     Funciones de utilidad visual - no necesarias para el funcionamiento del SDK     */
fun Activity.showToast(text: String, lenghtLong: Boolean = false) =
    Toast.makeText(this, text, if(lenghtLong) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
fun Activity.showToast(@StringRes textId: Int, lenghtLong: Boolean = false) =
    Toast.makeText(this, textId, if(lenghtLong) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

fun TextView.setWaitingMessage(message: String){
    text = message
    setTextColor(
        ContextCompat.getColor(context, android.R.color.white))
}

fun TextView.setWaitingMessage(@StringRes textId: Int){
    setText(textId)
    setTextColor(
        ContextCompat.getColor(context, android.R.color.white))
}

fun TextView.setSuccessMessage(message: String){
    text = message
    val value = TypedValue()
    context.theme.resolveAttribute(android.R.attr.colorAccent, value, true)
    setTextColor(value.data)
}

fun TextView.setSuccessMessage(@StringRes textId: Int){
    setText(textId)
    val value = TypedValue()
    context.theme.resolveAttribute(android.R.attr.colorAccent, value, true)
    setTextColor(value.data)
}

fun TextView.setErrorMessage(message: String){
    text = message
    setTextColor(ContextCompat.getColor(context, R.color.error))
}

fun TextView.setErrorMessage(@StringRes textId: Int){
    setText(textId)
    setTextColor(ContextCompat.getColor(context, R.color.error))
}

fun EditText.showError(error: String?){
    when {
        parent.parent is TextInputLayout -> {
            (parent.parent as TextInputLayout).isErrorEnabled = !error.isNullOrEmpty()
            (parent.parent as TextInputLayout).error = error
        }
        parent is TextInputLayout -> {
            (parent as TextInputLayout).isErrorEnabled = !error.isNullOrEmpty()
            (parent as TextInputLayout).error = error
        }
        else -> setError(error)
    }
}

/*     Funciones de parsing - no necesarias para el funcionamiento del SDK     */
fun BigDecimal.asCurrency(): String =
    NumberExtensions.currencyFormat.format(this.toDouble())

fun Long.asSimpleDate(): String =
    DateExtensions.simpleFormat.format(Date(this))

fun Long.asFullDate(): String =
    DateExtensions.fullFormat.format(Date(this))