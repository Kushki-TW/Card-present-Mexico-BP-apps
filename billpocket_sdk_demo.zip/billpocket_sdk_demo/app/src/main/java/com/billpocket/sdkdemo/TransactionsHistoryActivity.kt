package com.billpocket.sdkdemo

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.billpocket.bil_lib.controllers.HistoryTransactions
import com.billpocket.bil_lib.core.GetHistoryTransactionsResult
import com.billpocket.bil_lib.core.interfaces.EventListenerHistoryTransactions
import com.billpocket.bil_lib.models.entities.Transaction
import com.billpocket.sdkdemo.databinding.ActivityTransactionhistoryBinding
import com.billpocket.sdkdemo.utils.setErrorMessage
import com.billpocket.sdkdemo.utils.setSuccessMessage
import com.billpocket.sdkdemo.utils.setWaitingMessage
import com.google.gson.Gson

class TransactionsHistoryActivity: AppCompatActivity() {

    private lateinit var binding: ActivityTransactionhistoryBinding

    private val adapter by lazy {
        TransactionAdapter().apply {
            itemClickListener = { transaction ->
                requestRefund.launch(
                    Intent(this@TransactionsHistoryActivity,
                        TransactionDetailActivity::class.java).apply {
                            putExtra("DETAILS",
                                Gson().toJson(transaction, Transaction::class.java))
                    })
            }
        }
    }

    private val requestRefund =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
            if(it.resultCode == RESULT_OK)
                getTransactions()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_transactionhistory)
        binding.results.adapter = adapter

        //se obtiene el historial de transacción
        getTransactions()
    }

    private fun getTransactions(){
        //se muestra el mensaje de carga
        binding.results.visibility = View.INVISIBLE
        binding.historyStatus.visibility = View.VISIBLE
        binding.historyStatus.setWaitingMessage(getString(R.string.label_gettransactions))

        //se solicitan las transacciones
        HistoryTransactions.getHistoryTransaction(object: EventListenerHistoryTransactions{
            override fun resultHistoryTransaction(
                transactions: GetHistoryTransactionsResult<List<Transaction>?>) {
                when(transactions){
                    is GetHistoryTransactionsResult.Success  -> {
                        //si hay transacciones se carga la lista, de lo contrario se muestra un mensaje
                        transactions.data?.let { list ->
                            if(list.isEmpty())
                                binding.historyStatus.setSuccessMessage(
                                    getString(R.string.label_notransactions))
                            else {
                                binding.historyStatus.visibility = View.GONE
                                binding.results.visibility = View.VISIBLE
                                adapter.setItems(list)
                            }
                        } ?: run {
                            binding.historyStatus.setSuccessMessage(
                                getString(R.string.label_notransactions))
                        }
                    }
                    is GetHistoryTransactionsResult.Error ->
                        binding.historyStatus.setErrorMessage(
                            transactions.exception.message ?: "Error al obtener las transacciones")
                }
            }
        })
    }

}