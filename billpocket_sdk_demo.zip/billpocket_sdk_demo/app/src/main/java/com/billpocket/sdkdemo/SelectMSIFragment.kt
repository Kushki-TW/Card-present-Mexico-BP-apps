package com.billpocket.sdkdemo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.billpocket.bil_lib.models.transaction.Q6Descriptor
import com.billpocket.sdkdemo.databinding.DialogMsiselectorBinding
import com.billpocket.sdkdemo.utils.DataCallback
import com.billpocket.sdkdemo.utils.MSIOption
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.gson.Gson

class SelectMSIFragment: BottomSheetDialogFragment() {

    companion object {
        private const val ARG_INSTALLMENTS = "installments"

        fun newInstance(installments: List<Q6Descriptor>) =
            SelectMSIFragment().apply {
                arguments = Bundle().apply {
                    putStringArrayList(
                        ARG_INSTALLMENTS, ArrayList(installments.map { Gson().toJson(it) }))
                }
            }
    }

    private val installments by lazy {
        requireArguments().getStringArrayList(ARG_INSTALLMENTS)?.map {
            Gson().fromJson(it, Q6Descriptor::class.java)
        } ?: emptyList() }

    private val adapter by lazy {
        //se crea este adaptación porque el Adapter no soporta el tipo de dato Q6Descriptor
        MSIAdapter(installments.map { MSIOption(it.installments, it.commission, it.minAmount) }).apply {
            itemClickListener = {
                callback?.invoke(Q6Descriptor(it.fee, it.installments, it.minAmount))
                dismiss()
            }
        }
    }
    var callback: DataCallback<Q6Descriptor>? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = DataBindingUtil.inflate<DialogMsiselectorBinding>(
            inflater, R.layout.dialog_msiselector, container, false)
        binding.list.adapter = adapter
        return binding.root
    }

}