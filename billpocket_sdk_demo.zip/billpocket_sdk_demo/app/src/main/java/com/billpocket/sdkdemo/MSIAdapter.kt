package com.billpocket.sdkdemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.billpocket.sdkdemo.databinding.ItemMsiselectorBinding
import com.billpocket.sdkdemo.utils.ItemClickListener
import com.billpocket.sdkdemo.utils.MSIOption

class MSIAdapter(private val devices: List<MSIOption>):
    RecyclerView.Adapter<MSIAdapter.MSIViewHolder>(),
    View.OnClickListener {

    var itemClickListener: ItemClickListener<MSIOption>? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        MSIViewHolder(
            ItemMsiselectorBinding.inflate(LayoutInflater.from(parent.context), parent, false),
            this)

    override fun onBindViewHolder(holder: MSIViewHolder, position: Int) {
        holder.bind(devices[position])
    }

    override fun getItemCount() = devices.size

    override fun onClick(v: View?) { itemClickListener?.invoke(v?.tag as MSIOption) }

    //viewholder del selector
    inner class MSIViewHolder(
        private val binding: ItemMsiselectorBinding,
        clickListener: View.OnClickListener): RecyclerView.ViewHolder(binding.root){

        init { binding.root.setOnClickListener(clickListener) }

        fun bind(element: MSIOption){
            binding.element = element
            binding.executePendingBindings()
        }
    }

}